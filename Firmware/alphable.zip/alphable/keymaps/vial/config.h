/* SPDX-License-Identifier: GPL-2.0-or-later */

#pragma once

#define VIAL_KEYBOARD_UID {0xBE, 0x3C, 0xBC, 0x2A, 0xA4, 0x66, 0x7F, 0x10}

#define VIAL_UNLOCK_COMBO_ROWS {0}
#define VIAL_UNLOCK_COMBO_COLS {0}
